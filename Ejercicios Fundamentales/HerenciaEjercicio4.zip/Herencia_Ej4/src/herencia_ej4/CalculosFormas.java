/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herencia_ej4;

/**
 *
 * @author Maxi
 */
public interface CalculosFormas {
        public final double PI=Math.PI;
    
        public void calcularPerimetro();
        public void calcularArea(); 
    
}
